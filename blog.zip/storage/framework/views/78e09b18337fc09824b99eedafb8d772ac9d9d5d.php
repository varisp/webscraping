<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <?php if(session()->has('alert')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session()->get('alert')); ?>

            </div>

            <?php endif; ?>
            <a href="<?php echo e(route('posts.create')); ?>"><button class="btn btn-primary">Create Post</button></a>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Sl.No</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($post->id); ?></td>
                        <td class="overflow"><a href="<?php echo e(route('posts.show',$post->id)); ?>"><?php echo e($post->title); ?></a></td>
                        <td class="overflow"><?php echo e($post->description); ?></span></td>
                        <td><a href="<?php echo e(route('posts.edit',$post->id)); ?>"><button class="btn btn-success">Edit</button></a>
                            <form action="<?php echo e(route('posts.destroy',$post->id)); ?>" method="post"><?php echo method_field('delete'); ?> <?php echo csrf_field(); ?> <button class="btn btn-danger" type="submit">delete</button></form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($posts->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/home.blade.php ENDPATH**/ ?>