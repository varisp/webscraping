

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">


            <div class="container">
                <label for="title"><b>Title</b></label>
                <div><?php echo e($post->title); ?></div>
                
                <label for="description"><b>Description</b></label>
                <div><?php echo e($post->description); ?> </div>
                 
                <div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/posts/show.blade.php ENDPATH**/ ?>